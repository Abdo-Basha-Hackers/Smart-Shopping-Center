LcdBarGraphRobojax_I2C
============
Have been updated by Ahmad Shamshiri (May 15, 2019) from http://playground.arduino.cc/Code/LcdBarGraph

LcdBarGraphRobojax_I2C is an Arduino library to draw bar graph on a Liquid Chrystal display. This LcdBarGraphX is a fork of the original project to be driven by the "F. Malpartida" version LCD lib (aka. LiquidCrystal_I2C)

See page http://playground.arduino.cc/Code/LcdBarGraph for details.

See details about the I2C supported liquid chrystal library here: https://bitbucket.org/fmalpartida/new-liquidcrystal/wiki/Home
